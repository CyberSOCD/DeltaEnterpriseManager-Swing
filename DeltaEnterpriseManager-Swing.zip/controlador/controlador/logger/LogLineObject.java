package controlador.logger;

import java.util.Date;

import controlador.controlResult.GenericStatus.currentStatusValue;

public class LogLineObject {
	private Date fechaValidacion;
	private currentStatusValue estado;
	private String mensajeError;
	private int tiempoRespuesta;

	public Date getFechaValidacion() {
		return fechaValidacion;
	}

	public void setFechaValidacion(Date fechaValidacion) {
		this.fechaValidacion = fechaValidacion;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public int getTiempoRespuesta() {
		return tiempoRespuesta;
	}

	public void setTiempoRespuesta(int tiempoRespuesta) {
		this.tiempoRespuesta = tiempoRespuesta;
	}

	public currentStatusValue getEstado() {
		return estado;
	}

	public void setEstado(currentStatusValue estado) {
		this.estado = estado;
	};

}
