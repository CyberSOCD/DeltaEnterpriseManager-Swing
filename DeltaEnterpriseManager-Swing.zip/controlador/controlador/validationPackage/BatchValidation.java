package controlador.validationPackage;

import controlador.common.UserConnectionData;
import controlador.controlResult.GenericStatus;

public class BatchValidation extends Validation{

	
	public BatchValidation(UserConnectionData data){
		
	}
	@Override
	public void validate() throws Exception {
		
	}

	@Override
	public GenericStatus getCurrentStatus() {
		return null;
	}

	@Override
	protected void logActivity() {
		
	}

}
