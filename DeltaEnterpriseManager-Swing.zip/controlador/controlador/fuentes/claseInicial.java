package controlador.fuentes;


//import uiDialog.ProfileDialog;
import vista.ui.Frames.LoginFrame;

public class claseInicial {
	public static void main(String[] args) throws Exception {
//		ProfileDialog profileControl = new ProfileDialog();
		LoginFrame profileControl = new LoginFrame();
		profileControl.getTitle();
	}
}
