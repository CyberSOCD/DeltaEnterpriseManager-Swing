package controlador.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import controlador.controlResult.GenericStatus.currentStatusValue;
import controlador.logger.LogLineObject;

public class LogDAO {

	// private LogLineObject log;
	// private static String logPath;

	// Constantes
	private static String sep = " - ";
	private static String prueba_1 = "13/12/2017-14:59:21 - OK - Tiempo de respuesta: 162 milisegundos.";

	private static int datePosition = 0;
	private static int statusPosition = 1;
	private static int errorMsgPosition = 2;
	private static int simpleTimePosition = 2;
	private static int errorTimePosition = 3;

	/**
	 * Transforma una linea de log en un Objecto @LogLineObject
	 * 
	 * @param line
	 * @return lineObject
	 * @throws ParseException
	 */
	public static LogLineObject deserializedLogLine(String line)
			throws ParseException {
		LogLineObject lineObject = new LogLineObject();
		boolean errorLine = false;
		int timeValue;
		errorLine = line.split(sep).length == 4;
		String dateString = line.split(sep)[datePosition];
		String statusString = line.split(sep)[statusPosition];
		String errorString = "";
		String timeString;
		if (errorLine) {
			errorString = line.split(sep)[errorMsgPosition];
			timeString = line.split(sep)[errorTimePosition];
		} else {
			timeString = line.split(sep)[simpleTimePosition];
		}
		// Tratamiento de fecha
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy-HH:mm:ss");
		lineObject.setFechaValidacion(sdf.parse(dateString));
		// Tratamiento status
		lineObject.setEstado(currentStatusValue.valueOf(statusString));
		if (errorLine)
			lineObject.setMensajeError(errorString);
		// Tratamiento del tiempo de respuesta
		timeString = timeString.replace("Tiempo de respuesta: ", "").replace(
				" milisegundos.", "");
		timeValue = Integer.parseInt(timeString);
		// timeValue = Integer.getInteger();
		lineObject.setTiempoRespuesta(timeValue);
		return lineObject;
	}

	/**
	 * Transforma en un String el objeto pasado
	 * 
	 * @param lineObject
	 * @return
	 */
	public static String serializeLineLog(LogLineObject lineObject) {
		
		return "";
	}

}
