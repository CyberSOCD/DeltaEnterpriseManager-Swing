package vista.ui.Panels.Status;

public interface GenericStatusPanel {

	public abstract void validateStatus();
	
	public abstract boolean isTesting();
}
